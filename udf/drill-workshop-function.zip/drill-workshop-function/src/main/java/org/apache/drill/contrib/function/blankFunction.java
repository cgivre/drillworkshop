package org.apache.drill.contrib.function;

import io.netty.buffer.DrillBuf;
import org.apache.drill.exec.expr.DrillSimpleFunc;
import org.apache.drill.exec.expr.annotations.FunctionTemplate;
import org.apache.drill.exec.expr.annotations.Output;
import org.apache.drill.exec.expr.annotations.Param;
import org.apache.drill.exec.expr.annotations.Workspace;
import org.apache.drill.exec.expr.holders.BigIntHolder;
import org.apache.drill.exec.expr.holders.NullableVarCharHolder;

import javax.inject.Inject;


@FunctionTemplate(
    name = "function_name",  //Put your function name here...
    scope = FunctionTemplate.FunctionScope.SIMPLE,
    nulls = FunctionTemplate.NullHandling.NULL_IF_NULL
)
public class blankFunction  implements DrillSimpleFunc {

    @Param
    NullableVarCharHolder inputTextA;  //put input parameters in this manner

    @Param
    BigIntHolder num;

    @Output BigIntHolder out;  //output parameters like this

    @Inject
    DrillBuf buffer;

    @Workspace
    int x;  //Use the workspace to declare variables which are common for each function iteration


    //The setup function is where you do any preparation for the function calculations, such as
    public void setup() {
        x = 1;  //Or whatever ;-)
    }


    /*The eval() function is where you actually perform the calculation.
    * Note that this function does not actually return anything.  You set the out value that you declared earlier
    * All strings that you get from Drill must be captured using the method demonstrated below
    */
    public void eval() {
        String some_string = org.apache.drill.exec.expr.fn.impl.StringFunctionHelpers.toStringFromUTF8(inputTextA.start, inputTextA.end, inputTextA.buffer);
        long z = num.value;
        out.value = x;
    }


}