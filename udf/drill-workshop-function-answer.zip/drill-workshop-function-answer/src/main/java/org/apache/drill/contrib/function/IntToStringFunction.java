package org.apache.drill.contrib.function;

import io.netty.buffer.DrillBuf;
import org.apache.drill.exec.expr.DrillSimpleFunc;
import org.apache.drill.exec.expr.annotations.FunctionTemplate;
import org.apache.drill.exec.expr.annotations.Output;
import org.apache.drill.exec.expr.annotations.Param;
import org.apache.drill.exec.expr.holders.IntHolder;
import org.apache.drill.exec.expr.holders.VarCharHolder;

import javax.inject.Inject;


@FunctionTemplate(
    name = "int_to_string",  //Put your function name here...
    scope = FunctionTemplate.FunctionScope.SIMPLE,
    nulls = FunctionTemplate.NullHandling.NULL_IF_NULL
)
public class IntToStringFunction  implements DrillSimpleFunc {

    @Param
    IntHolder input_int;

    @Output
    VarCharHolder out;  //output parameters like this

    @Inject
    DrillBuf buffer;

    //The setup function is where you do any preparation for the function calculations, such as
    public void setup() {
    }


    /*The eval() function is where you actually perform the calculation.
    * Note that this function does not actually return anything.  You set the out value that you declared earlier
    * All strings that you get from Drill must be captured using the method demonstrated below
    */
    public void eval() {
        int x = input_int.value;
        String result = "";
        if ( x == 0 ){
            result = "Zero";
        } else if( x == 1 ){
            result = "One";
        } else if( x == 2 ){
            result = "Two";
        } else if( x == 3 ){
            result = "Three";
        } else if( x == 4 ) {
            result = "Four";
        } else if( x == 5 ){
            result = "Five";
        } else if( x == 6 ){
            result = "Six";
        } else if( x == 7 ){
            result = "Seven";
        } else if( x == 8) {
            result = "Eight";
        }else if( x == 9){
            result = "Nine";
        }

        String outputValue = result;

        out.buffer = buffer;
        out.start = 0;
        out.end = outputValue.getBytes().length;
        buffer.setBytes(0, outputValue.getBytes());
    }


}